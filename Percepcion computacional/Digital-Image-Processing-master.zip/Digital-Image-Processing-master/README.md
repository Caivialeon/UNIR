# Digital-Image-Processing
This repository includes all Basic Algorithms related to image Processing, these are almost without Build-in Functions.
These include
->Connected component analysis
->Transformation Operations
->Spatial Filtering
->Edge Detection
->Segmentation 
->Morphological Operations
->Color Processing
->Frequency Analysis
->Texture Analysis
->CNN based Classification
->Local Binary Pattern
